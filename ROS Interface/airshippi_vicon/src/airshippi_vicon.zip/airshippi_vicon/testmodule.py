import numpy as np

def test():
    return 1